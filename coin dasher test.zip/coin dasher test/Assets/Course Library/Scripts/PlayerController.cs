using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    private float speed = 40.0f;         // Speed of the player
    private float horizontalInput;        // Input for horizontal movement
    private float forwardInput;           // Input for forward movement
    public SpawnManager spawnManager;
    public bool gameOver;

    void Update()
    {
        // Get input from the user
        horizontalInput = Input.GetAxis("Horizontal");
        

        // Move the player forward based on vertical input
        transform.Translate(Vector3.forward * Time.deltaTime * speed);

        // Rotate the player based on horizontal input
        transform.Translate(Vector3.right * Time.deltaTime * speed * horizontalInput);
    }

    private void OnTriggerEnter(Collider other)
    {
    
        spawnManager.SpawnTriggerEntered();

    }

    private void OnCollisionEnter(Collision other)
        {
            // Check if the collision is with a crate
            if (other.gameObject.CompareTag("Crate_01"))
            {
                gameOver = true;
                Debug.Log("Game Over!");

                // Load the Game Over scene
                SceneManager.LoadScene("GameOver");
            }
}

}