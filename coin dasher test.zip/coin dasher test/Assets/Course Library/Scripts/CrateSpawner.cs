using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrateSpawner : MonoBehaviour
{
    public GameObject cratePrefab; // The crate prefab to spawn
    public float spawnInterval = 50.0f; // Interval between spawns
    public int numberOfCrates = 1; // Number of crates to spawn per interval
    public float roadLength = 50.0f; // Length of the road
    public float roadWidth = 5.0f; // Width of the road

    private void Start()
    {
        // Start spawning crates at regular intervals
        StartCoroutine(SpawnCratesRoutine());
    }

    private IEnumerator SpawnCratesRoutine()
    {
        while (true)
        {
            SpawnCrates();
            yield return new WaitForSeconds(spawnInterval);
        }
    }

    private void SpawnCrates()
    {
        for (int i = 0; i < numberOfCrates; i++)
        {
            // Randomize position within the road's length and width
            float randomZ = Random.Range(-roadLength / 2f, roadLength / 2f); // Road length along z-axis
            float randomX = Random.Range(-roadWidth / 1.5f, roadWidth / 1.5f);   // Road width along x-axis

            // Create a spawn position for the crate
            Vector3 spawnPosition = new Vector3(randomX, 0, randomZ) + transform.position;

            // Instantiate the crate at the spawn position with default rotation
            Instantiate(cratePrefab, spawnPosition, Quaternion.identity);
        }
    }
}
