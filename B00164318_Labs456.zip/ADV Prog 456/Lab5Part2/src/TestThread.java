public class TestThread {
    public static void main(String[] args) {
        // Create and start five threads using Runnable
        for (int i = 1; i <= 5; i++) {
            Runnable task = new ThreadUsingRunnable();
            Thread thread = new Thread(task);
            thread.setName("Malaj " + i); // Set thread name dynamically
            thread.start();
        }
    }
}
