public class ThreadUsingRunnable implements Runnable {
    private static int[] numbers = {1, 2, 3, 4};

    @Override
    public void run() {
        for (int num : numbers) {
            System.out.println(Thread.currentThread().getName() + " " + num);
        }
    }
}
