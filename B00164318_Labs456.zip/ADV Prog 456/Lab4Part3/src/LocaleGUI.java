import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.DateFormatSymbols;


public class LocaleGUI {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LocaleGUI().createAndShowGUI());
    }

    public void createAndShowGUI() {
        // Create frame
        JFrame frame = new JFrame("Display Localized Information Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        // Create a combo box with locales
        JComboBox<String> localeComboBox = new JComboBox<>();
        Locale[] availableLocales = Locale.getAvailableLocales();
        for (Locale locale : availableLocales) {
            localeComboBox.addItem(locale.getDisplayName());
        }

        // Create text area to display information
        JTextArea textArea = new JTextArea(10, 40);
        textArea.setEditable(false);

        // Add components to frame
        frame.setLayout(new FlowLayout());
        frame.add(new JLabel("Select Locale:"));
        frame.add(localeComboBox);
        frame.add(new JScrollPane(textArea));

        // Add listener to combo box to update text area
        localeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Locale selectedLocale = availableLocales[localeComboBox.getSelectedIndex()];
                StringBuilder sb = new StringBuilder();
                sb.append("Days of the week in ").append(selectedLocale.getDisplayName()).append(":\n");
                displayDaysOfWeek(selectedLocale, sb);
                sb.append("\nMonths of the year in ").append(selectedLocale.getDisplayName()).append(":\n");
                displayMonths(selectedLocale, sb);
                textArea.setText(sb.toString());
            }
        });

        frame.setVisible(true);
    }

    public void displayDaysOfWeek(Locale locale, StringBuilder sb) {
        DateFormatSymbols dfs = new DateFormatSymbols(locale);
        String[] daysOfWeek = dfs.getWeekdays();
        for (int i = 1; i <= 7; i++) {
            sb.append(daysOfWeek[i]).append("\n");
        }
    }

    public void displayMonths(Locale locale, StringBuilder sb) {
        DateFormatSymbols dfs = new DateFormatSymbols(locale);
        String[] months = dfs.getMonths();
        for (String month : months) {
            if (!month.isEmpty()) {
                sb.append(month).append("\n");
            }
        }
    }
}
