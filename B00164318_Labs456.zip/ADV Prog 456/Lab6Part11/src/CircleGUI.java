import javax.swing.*;
import java.awt.*;

/**
 * GUI class to calculate the circumference of a circle based on the radius input.
 */
public class CircleGUI extends JFrame {
    private JTextField radiusField;
    private JLabel resultLabel;

    /**
     * Constructor to set up the GUI components.
     */
    public CircleGUI() {
        setTitle("Circle Circumference Calculator");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Label for radius input
        JLabel radiusLabel = new JLabel("Enter Radius:");
        add(radiusLabel);

        // Text field for radius input
        radiusField = new JTextField(10);
        add(radiusField);

        // Button to calculate circumference
        JButton calculateButton = new JButton("Calculate");
        add(calculateButton);

        // Label to display the result
        resultLabel = new JLabel("Circumference: ");
        add(resultLabel);

        // Lambda expression to handle the button click event
        calculateButton.addActionListener(e -> {
            // Parse the radius input
            try {
                double radius = Double.parseDouble(radiusField.getText());
                // Calculate the circumference using the Utility class
                double circumference = Utility.calculateCircumference(radius);
                // Display the result
                resultLabel.setText("Circumference: " + circumference);
            } catch (NumberFormatException ex) {
                resultLabel.setText("Invalid input. Please enter a valid number.");
            }
        });
    }

    /**
     * Main method to run the GUI.
     */
    public static void main(String[] args) {
        // Create and display the GUI
        SwingUtilities.invokeLater(() -> {
            CircleGUI frame = new CircleGUI();
            frame.setVisible(true);
        });
    }
}
