/**
 * Utility class for mathematical calculations related to circles.
 */
public class Utility {
    // Constant value of PI
    public static final double PI = 3.14159;

    /**
     * Method to calculate the circumference of a circle.
     *
     * @param radius the radius of the circle
     * @return the circumference of the circle
     */
    public static double calculateCircumference(double radius) {
        return 2 * PI * radius;
    }
}
