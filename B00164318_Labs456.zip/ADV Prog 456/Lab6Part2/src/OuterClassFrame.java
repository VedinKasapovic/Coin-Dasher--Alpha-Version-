import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Field;

/**
 * Outer class with a GUI to demonstrate inner class functionality and reflection.
 */
public class OuterClassFrame extends JFrame {
    private JTextArea textArea;
    private String outerField = "Outer class field value";

    /**
     * Constructor to set up the outer class GUI components.
     */
    public OuterClassFrame() {
        setTitle("Inner/Outer Class Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // JTextArea to display the output
        textArea = new JTextArea(10, 30);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Button to trigger reflection
        JButton infoButton = new JButton("Get Class Info");
        add(infoButton, BorderLayout.SOUTH);

        // Inner class instantiation
        new InnerInfoClass(infoButton);  // Pass the button to the inner class
    }

    /**
     * Inner class that performs the reflection and updates the text area.
     */
    class InnerInfoClass {
        /**
         * Constructor to add button listener with an anonymous inner class.
         *
         * @param button the button to attach the listener
         */
        public InnerInfoClass(JButton button) {
            // Anonymous inner class for button listener
            button.addActionListener(e -> {
                // Using reflection to get the class name
                String innerClassName = this.getClass().getName();
                String outerClassName = OuterClassFrame.this.getClass().getName();

                // Display class names in the text area
                textArea.append("Inner class: " + innerClassName + "\n");
                textArea.append("Outer class: " + outerClassName + "\n");

                // Display the fields of the outer class using reflection
                Field[] fields = OuterClassFrame.this.getClass().getDeclaredFields();
                for (Field field : fields) {
                    textArea.append("Field: " + field.getName() + "\n");
                }
            });
        }
    }

    /**
     * Main method to run the outer class.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            OuterClassFrame frame = new OuterClassFrame();
            frame.setVisible(true);
        });
    }
}
