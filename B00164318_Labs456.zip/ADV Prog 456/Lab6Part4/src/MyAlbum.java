import javax.swing.*;
import java.awt.*;
import java.util.Vector;

/**
 * Abstract class representing an album item (e.g., an image with facts).
 */
abstract class AlbumItem {
    public abstract ImageIcon getImage();
    public abstract String getFacts();
}

/**
 * Subclass representing a favourite sport.
 */
class FavouriteSport extends AlbumItem {
    private String sportName;
    private String originOfSport;
    private String mainScoreType;

    public FavouriteSport(String sportName, String originOfSport, String mainScoreType) {
        this.sportName = sportName;
        this.originOfSport = originOfSport;
        this.mainScoreType = mainScoreType;
    }

    @Override
    public ImageIcon getImage() {
        return new ImageIcon("sport.jpg");  // Placeholder for the image
    }

    @Override
    public String getFacts() {
        return "Sport: " + sportName + "\nOrigin: " + originOfSport + "\nScore type: " + mainScoreType;
    }
}

/**
 * Subclass representing a favourite animal.
 */
class FavouriteAnimal extends AlbumItem {
    private String animalName;
    private String habitat;

    public FavouriteAnimal(String animalName, String habitat) {
        this.animalName = animalName;
        this.habitat = habitat;
    }

    @Override
    public ImageIcon getImage() {
        return new ImageIcon("animal.jpg");  // Placeholder for the image
    }

    @Override
    public String getFacts() {
        return "Animal: " + animalName + "\nHabitat: " + habitat;
    }
}

/**
 * Main GUI class that displays the images and facts of the album items.
 */
public class MyAlbum extends JFrame {
    private Vector<AlbumItem> albumItems;
    private int currentIndex = 0;

    public MyAlbum() {
        albumItems = new Vector<>();
        albumItems.add(new FavouriteSport("Football", "England", "Goal"));
        albumItems.add(new FavouriteAnimal("Camel", "Sahara"));

        setTitle("My Album");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // JLabel to display image
        JLabel imageLabel = new JLabel();
        add(imageLabel, BorderLayout.CENTER);

        // JTextArea to display facts
        JTextArea factsArea = new JTextArea(5, 30);
        factsArea.setEditable(false);
        add(new JScrollPane(factsArea), BorderLayout.SOUTH);

        // Button to navigate forward
        JButton forwardButton = new JButton("Next");
        add(forwardButton, BorderLayout.NORTH);

        forwardButton.addActionListener(e -> {
            if (currentIndex < albumItems.size() - 1) {
                currentIndex++;
            } else {
                currentIndex = 0;  // Loop back to the first item
            }

            // Update the image and facts
            AlbumItem currentItem = albumItems.get(currentIndex);
            imageLabel.setIcon(currentItem.getImage());
            factsArea.setText(currentItem.getFacts());
        });

        // Set initial image and facts
        AlbumItem firstItem = albumItems.get(currentIndex);
        imageLabel.setIcon(firstItem.getImage());
        factsArea.setText(firstItem.getFacts());
    }

    /**
     * Main method to run the album.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MyAlbum frame = new MyAlbum();
            frame.setVisible(true);
        });
    }
}
