import java.text.*;
import java.util.*;

public class OutputInternationalInformation {

    public static void main(String[] args) {
        // Create Locale objects for your choice
        Locale locale1 = new Locale("it", "IT"); // Italian, Italy
        Locale locale2 = new Locale("en", "US"); // English, United States
        Locale locale3 = new Locale("es", "ES"); // Spanish, Spain

        // Call method with different locales
        displayLocalizedInformation(locale1);
        displayLocalizedInformation(locale2);
        displayLocalizedInformation(locale3);
    }

    public static void displayLocalizedInformation(Locale locale) {
        // Display days of the week
        DateFormatSymbols dfs = new DateFormatSymbols(locale);
        String[] daysOfWeek = dfs.getWeekdays();
        System.out.println("Days of the week in " + locale.getDisplayName() + ":");
        for (int i = 1; i <= 7; i++) {
            System.out.println(daysOfWeek[i]);
        }

        // Display months of the year
        String[] months = dfs.getMonths();
        System.out.println("\nMonths of the year in " + locale.getDisplayName() + ":");
        for (String month : months) {
            if (!month.isEmpty()) {
                System.out.println(month);
            }
        }

        // Display currency
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
        System.out.println("\nCurrency in " + locale.getDisplayName() + ": " + currencyFormatter.format(10000.50));

        // Display today's date in short format
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT, locale);
        System.out.println("\nToday's date in SHORT format: " + dateFormat.format(new Date()));

        // Display one additional locale-sensitive information (e.g., country name)
        System.out.println("\nCountry in " + locale.getDisplayName() + ": " + locale.getDisplayCountry());

        System.out.println("\n-------------------------------------\n");
    }
}
