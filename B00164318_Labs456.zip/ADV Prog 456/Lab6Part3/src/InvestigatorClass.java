import javax.swing.*;
import java.awt.*;
import java.lang.reflect.*;


/**
 * JFrame to investigate methods of the MysteryJarClass using reflection.
 */
public class InvestigatorClass extends JFrame {
    private JTextArea textArea;

    /**
     * Constructor to set up the GUI.
     */
    public InvestigatorClass() {
        setTitle("Class Reflection Investigator");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // JTextArea to display the results of reflection
        textArea = new JTextArea(10, 40);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Button to trigger reflection
        JButton investigateButton = new JButton("Investigate MysteryJarClass");
        add(investigateButton, BorderLayout.SOUTH);

        // ActionListener for the button to perform reflection
        investigateButton.addActionListener(e -> {
            try {
                // Load the MysteryJarClass using reflection
                Class<?> mysteryClass = Class.forName("mystery.MysteryJarClass");
                textArea.append("Investigating class: " + mysteryClass.getName() + "\n");

                // Get and display all method names and parameter types
                Method[] methods = mysteryClass.getDeclaredMethods();
                for (Method method : methods) {
                    textArea.append("Method: " + method.getName() + "\n");
                    Parameter[] parameters = method.getParameters();
                    for (Parameter param : parameters) {
                        textArea.append("  Parameter: " + param.getType().getName() + "\n");
                    }
                }

                // Invoke the method with no parameters (if it exists)
                Method noParamMethod = mysteryClass.getDeclaredMethod("noParamMethod");
                noParamMethod.setAccessible(true); // For private methods
                noParamMethod.invoke(mysteryClass.getDeclaredConstructor().newInstance());
                textArea.append("Method 'noParamMethod' invoked successfully.\n");

            } catch (Exception ex) {
                textArea.append("Error: " + ex.getMessage() + "\n");
            }
        });
    }

    /**
     * Main method to run the InvestigatorClass.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InvestigatorClass frame = new InvestigatorClass();
            frame.setVisible(true);
        });
    }
}
