public class ThreadUsingExtends extends Thread {
    private static String[] letters = {"A", "B", "C", "D"};
    private int threadNumber;

    // Constructor to name the thread and pass its number
    public ThreadUsingExtends(int threadNumber) {
        this.threadNumber = threadNumber;
        this.setName("Malaj " + threadNumber); // Name thread dynamically
    }

    @Override
    public void run() {
        for (String letter : letters) {
            // Print the thread's name with the letter
            System.out.println(Thread.currentThread().getName() + " " + letter);
        }
    }
}
