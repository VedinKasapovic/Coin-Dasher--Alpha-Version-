public class TestThread {
    public static void main(String[] args) {
        // Create and start five threads
        for (int i = 1; i <= 5; i++) {
            ThreadUsingExtends thread = new ThreadUsingExtends(i);
            thread.start(); // Start the thread
        }
    }
}
