import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class InternationalizedGUI {
    // Declare UI components as instance variables
    private JFrame frame;
    private JButton button1, button2, button3, englishButton, frenchButton, spanishButton;
    private ResourceBundle bundle;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InternationalizedGUI().createAndShowGUI());
    }

    public void createAndShowGUI() {
        // Default locale (can change based on user selection)
        Locale locale = Locale.getDefault();  // Get the default locale, e.g., en_US
        bundle = ResourceBundle.getBundle("messages", locale);  // Load corresponding properties file

        // Create frame
        frame = new JFrame(bundle.getString("greeting"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        // Create buttons
        button1 = new JButton(bundle.getString("button1"));
        button2 = new JButton(bundle.getString("button2"));
        button3 = new JButton(bundle.getString("button3"));

        // Panel for buttons in the center
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);

        // Load and resize flag images
        ImageIcon englishFlag = resizeImageIcon("C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\images\\england.png", 40, 40);
        ImageIcon frenchFlag = resizeImageIcon("C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\images\\france.png", 40, 40);
        ImageIcon spanishFlag = resizeImageIcon("C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\images\\spain.png", 40, 40);

        // Create language selection buttons with resized flags
        englishButton = new JButton("English", englishFlag);
        frenchButton = new JButton("French", frenchFlag);
        spanishButton = new JButton("Spanish", spanishFlag);

        // Panel for language selection
        JPanel languagePanel = new JPanel();
        languagePanel.add(englishButton);
        languagePanel.add(frenchButton);
        languagePanel.add(spanishButton);

        // Add action listeners to language buttons
        englishButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeLanguage(new Locale("en", "US"));
            }
        });

        frenchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeLanguage(new Locale("fr", "FR"));
            }
        });

        spanishButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeLanguage(new Locale("es", "ES"));
            }
        });

        // Set layout and add components
        frame.setLayout(new BorderLayout());
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(languagePanel, BorderLayout.SOUTH);

        // Show the frame
        frame.setVisible(true);
    }

    public void changeLanguage(Locale locale) {
        // Load the resource bundle for the selected locale
        bundle = ResourceBundle.getBundle("messages", locale);

        // Update frame title and button texts based on the selected language
        frame.setTitle(bundle.getString("greeting"));
        button1.setText(bundle.getString("button1"));
        button2.setText(bundle.getString("button2"));
        button3.setText(bundle.getString("button3"));
        englishButton.setText(bundle.getString("languageSelect"));
        frenchButton.setText(bundle.getString("languageSelect"));
        spanishButton.setText(bundle.getString("languageSelect"));
    }

    // Helper method to resize images
    public ImageIcon resizeImageIcon(String imagePath, int width, int height) {
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage(); // transform it
        Image resizedImage = image.getScaledInstance(width, height,  java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImage); // return the new icon
    }
}
