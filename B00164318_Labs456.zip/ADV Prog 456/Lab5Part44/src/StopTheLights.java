import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StopTheLights extends JFrame {
    private TrafficLightThread trafficLightThread;

    public StopTheLights() {
        // Set up the frame
        setTitle("Traffic Lights");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Add buttons
        JButton startButton = new JButton("Start");
        JButton stopButton = new JButton("Stop");
        JPanel panel = new JPanel();
        panel.add(startButton);
        panel.add(stopButton);
        add(panel, BorderLayout.SOUTH);

        // Action listeners
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startTrafficLights();
            }
        });

        stopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                stopTrafficLights();
            }
        });
    }

    public void startTrafficLights() {
        trafficLightThread = new TrafficLightThread();
        trafficLightThread.start();
    }

    public void stopTrafficLights() {
        if (trafficLightThread != null) {
            trafficLightThread.interrupt(); // Stop the thread
        }
    }

    // Draw traffic lights
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.RED);
        g.fillOval(100, 100, 50, 50); // Draw red light
        g.setColor(Color.YELLOW);
        g.fillOval(100, 160, 50, 50); // Draw yellow light
        g.setColor(Color.GREEN);
        g.fillOval(100, 220, 50, 50); // Draw green light
    }

    // Traffic light thread
    class TrafficLightThread extends Thread {
        public void run() {
            try {
                while (!Thread.interrupted()) {
                    Thread.sleep(2000); // Wait for 2 seconds before switching
                    repaint(); // Change light every 2 seconds
                }
            } catch (InterruptedException e) {
                System.out.println("Traffic light sequence stopped.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                StopTheLights frame = new StopTheLights();
                frame.setVisible(true);
            }
        });
    }
}
