public class ThreadUsingExtends extends Thread {
    private static String[] letters = {"A", "B", "C", "D"};
    private static final Object lock = new Object(); // Lock for synchronization
    private int threadNumber;

    public ThreadUsingExtends(int threadNumber) {
        this.threadNumber = threadNumber;
        this.setName("Malaj " + threadNumber);
    }

    @Override
    public void run() {
        synchronized (lock) {
            for (String letter : letters) {
                System.out.println(Thread.currentThread().getName() + " " + letter);
                try {
                    Thread.sleep(100); // Small delay to simulate processing
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
