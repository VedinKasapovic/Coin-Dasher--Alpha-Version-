import java.util.regex.*;

public class RegexExample {
    public static void main(String[] args) {
        // Create a random string with multiple instances of the first name and surname
        String randomText = "John Smith was walking down the street. Jane Smith and John Smith were talking. " +
                "Smith asked Jane to meet at the park. John was happy.";

        // Define the pattern for matching the first name or surname
        String pattern = "(John|Smith)"; // Matches either "John" or "Smith"

        // Create the Pattern and Matcher
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(randomText);

        // Find and print the locations of each match
        while (matcher.find()) {
            System.out.println("Found: " + matcher.group() + " at index: " + matcher.start());
        }
    }
}
