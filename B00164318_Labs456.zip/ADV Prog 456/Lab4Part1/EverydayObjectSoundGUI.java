import javax.swing.*;
import javax.sound.sampled.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class EverydayObjectSoundGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Everyday Object Sound");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel for buttons
        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setLayout(new GridLayout(1, 3));

        // Buttons for objects
        JButton bikeButton = createButton("Bike", "C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\sounds\\bike.wav");
        JButton formulaButton = createButton("Formula 1 Car", "C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\sounds\\formula.wav");
        JButton phoneButton = createButton("Phone", "C:\\Users\\KM017\\IdeaProjects\\ADV Prog 456\\sounds\\phone.wav");

        // Add buttons to the panel
        panel.add(bikeButton);
        panel.add(formulaButton);
        panel.add(phoneButton);

        // Make the frame visible
        frame.setVisible(true);
    }

    // Creates a button that plays sound on click
    private static JButton createButton(String label, String soundFileName) {
        JButton button = new JButton(label);
        button.setIcon(new ImageIcon(label + ".png")); // Use image representing the object

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound(soundFileName);
            }
        });

        return button;
    }

    // Method to play the sound
    private static void playSound(String soundFileName) {
        try {
            File soundFile = new File(soundFileName); // Ensure the .wav file is in the project directory
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
